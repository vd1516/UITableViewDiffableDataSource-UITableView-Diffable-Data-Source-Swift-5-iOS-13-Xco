//
//  ViewController.swift
//  TableviewDifferable
//
//  Created by vrushabh on 25/04/21.
//

import UIKit

typealias UserDataSource = UITableViewDiffableDataSource<TblSection,UserModel>
typealias UserSnapshot = NSDiffableDataSourceSnapshot<TblSection,UserModel>

class ViewController: UIViewController {

    @IBOutlet weak var tbl: UITableView!
    
    var dataSource : UserDataSource!
    var arrData = [UserModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureDataSource()
        arrData = addUserData()
        createSnapshot(user: arrData)
        
    }

    //Config datasource
    func configureDataSource() {
        dataSource = UserDataSource(tableView: tbl, cellProvider: { (tbl, indexpath, user) -> UITableViewCell? in
            let cell = tbl.dequeueReusableCell(withIdentifier: "cell", for: indexpath)
            cell.textLabel?.text = user.name
            return cell
        })
    }
    
    //Create a snapshot
    func createSnapshot(user: [UserModel]) {
        var snapshot = UserSnapshot()
        snapshot.appendSections([.first])
        snapshot.appendItems(user)
        dataSource.apply(snapshot, animatingDifferences: true, completion: nil)
    }
    
    //Add array data
    func addUserData() -> [UserModel] {
        return [
            UserModel(name: "ABC"),
            UserModel(name: "XYZ"),
            UserModel(name: "EER"),
            UserModel(name: "RTY"),
            UserModel(name: "cxb")
        ]
    }

    
}

struct UserModel : Hashable{
    var name : String?
}

enum TblSection {
    case first
}

extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let user = dataSource.itemIdentifier(for: indexPath)
        print(user?.name)
    }
}
