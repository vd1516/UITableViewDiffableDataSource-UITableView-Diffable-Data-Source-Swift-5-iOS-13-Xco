//
//  ApiVC.swift
//  TableviewDifferable
//
//  Created by vrushabh on 25/04/21.
//

import UIKit

class ApiVC: UIViewController {

    @IBOutlet weak var tbl: UITableView!
    
    typealias UserDataSource = UITableViewDiffableDataSource<TblSection,DataModel>
    typealias UserSnapshot = NSDiffableDataSourceSnapshot<TblSection,DataModel>
    
    var dataSource : UserDataSource!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureDataSource()
        DataHelper.ShareInstance.getData { (result) in
            switch result{
            case .success( _):
                self.createSnapshot(data: DataHelper.ShareInstance.arrData)
                break
            case .failure(let error):
                print(error.localizedDescription)
                break
            }
        }
        
    }

    private func configureDataSource(){
        dataSource = UserDataSource(tableView: tbl, cellProvider: { (tbl, indexPath, data) -> UITableViewCell? in
            let cell = tbl.dequeueReusableCell(withIdentifier: "UserCell", for: indexPath)
            cell.textLabel?.text = data.title
            return cell
        })
    }

    private func createSnapshot(data: [DataModel]){
        var snapShot = UserSnapshot()
        snapShot.appendSections([.first])
        snapShot.appendItems(data)
        dataSource.apply(snapShot)

    }
}

extension ApiVC : UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let data = dataSource.itemIdentifier(for: indexPath)
        print(data?.title)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
}
