//
//  DataHelper.swift
//  TableviewDifferable
//
//  Created by vrushabh on 25/04/21.
//

import UIKit
import Alamofire

enum APIError: Error {
    case custom(message: String)
}

typealias Result = (Swift.Result<Bool,APIError>) -> Void

class DataHelper: NSObject {
    
    static let ShareInstance = DataHelper()
    var dataURL = URL(string: "https://jsonplaceholder.typicode.com/todos")
    var arrData = [DataModel]()
    
    func getData(completion : @escaping(Result)){
        AF.request(dataURL as! URLConvertible,method: .get,encoding: JSONEncoding.default,headers: [:]).responseJSON { (response) in
            switch response.result{
            case .success(let json) :
                print(json)
                if let data = response.data{
                    do{
                        let userData = try JSONDecoder().decode([DataModel].self,from :data)
                        self.arrData.append(contentsOf: userData)
                        completion(.success(true))
                    }catch{
                        print("Catch")
                        completion(.failure(.custom(message: "Request failed.please try again after some time!")))
                    }
                }
                break
            case .failure(let error) :
                print(error.localizedDescription)
                completion(.failure(.custom(message: error.localizedDescription)))
                break
            }
        }
    }
}
